package com.alfacentauri.cloud.usuarios.respository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

import com.alfacentauri.cloud.commons.usuarios.entitys.Usuario;

@RepositoryRestResource(path = "usuarios")
 public interface UsuarioRepository extends PagingAndSortingRepository<Usuario, Long> {
	
	// Ruta personalizada
	@RestResource(path = "buscar-username")
	public Usuario findByUsername(@Param("username") String username);
//	public Usuario findByUsernameAndEmail(String username, String email);
	
	@Query(value = "SELECT u FROM Usuario u WHERE u.username=?1")
	public Usuario obtenerPorUsername(String username);
}
