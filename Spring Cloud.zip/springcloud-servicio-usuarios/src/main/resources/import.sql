INSERT INTO usuarios (username, password, enabled, nombre, email) VALUES('root', '$2a$10$7.nxHZ0Aj16z/NwQ36e3De8H9f0ZziYpDgDgzMSEUBThMuCsjWzGe', true, 'Usuario Root', 'root@mail.com');
INSERT INTO usuarios (username, password, enabled, nombre, email) VALUES('usuario', '$2a$10$WHtR2UdIpBh5o/y1TLxB/uRJ.FJcCHeMNGmEcKFH5N6tVyFY6e222', true, 'Usuario normal', 'usuario@mail.com');

INSERT INTO roles (nombre) VALUES ('ROLE_ADMIN');
INSERT INTO roles (nombre) VALUES ('ROLE_USER');

INSERT INTO usuarios_to_roles (user_id, role_id) VALUES (1,1);
INSERT INTO usuarios_to_roles (user_id, role_id) VALUES (1,2);
INSERT INTO usuarios_to_roles (user_id, role_id) VALUES (2,2);
