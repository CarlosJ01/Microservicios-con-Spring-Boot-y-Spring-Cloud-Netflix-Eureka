package com.alfacentauri.cloud.productos.models.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.alfacentauri.cloud.commons.entitys.Producto;

@Repository
public interface ProductDAO extends CrudRepository<Producto, Long>{
	
}
