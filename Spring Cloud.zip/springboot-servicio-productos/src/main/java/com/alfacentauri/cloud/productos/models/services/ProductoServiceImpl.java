package com.alfacentauri.cloud.productos.models.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alfacentauri.cloud.commons.entitys.Producto;
import com.alfacentauri.cloud.productos.models.dao.ProductDAO;

@Service
public class ProductoServiceImpl implements IProductoService{
	
	@Autowired
	private ProductDAO productDAO;
	
	@Override
	@Transactional(readOnly = true)
	public List<Producto> findAll() {
		return (List<Producto>) productDAO.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Producto findById(Long id) {
		return productDAO.findById(id).orElse(null); // Regresa el objeto si esta si no null o lo que se especifique
	}

	@Override
	@Transactional
	public Producto save(Producto producto) {
		return productDAO.save(producto);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		productDAO.deleteById(id);
	}

}
