package com.alfacentauri.cloud.commons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcloudCommonsApplicationTests {

	@Test
	void contextLoads() {
	}

}
