package com.alfacentauri.cloud.zuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcloudZuulServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
