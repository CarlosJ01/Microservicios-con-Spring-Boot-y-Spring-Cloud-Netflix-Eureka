package com.alfacentauri.cloud.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class SpringcloudGatewayServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcloudGatewayServerApplication.class, args);
	}

}
