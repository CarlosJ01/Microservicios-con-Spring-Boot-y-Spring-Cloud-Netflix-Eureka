package com.alfacentauri.cloud.gateway.filters.Factory;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.OrderedGatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Component;

import reactor.core.publisher.Mono;

@Component
public class EjemploGatewayFilterFactory extends AbstractGatewayFilterFactory<EjemploGatewayFilterFactory.Configuration>{ // Clase abstracta
	
	private final Logger logger = LoggerFactory.getLogger(EjemploGatewayFilterFactory.class);
	
	public EjemploGatewayFilterFactory() {
		super(Configuration.class);
	}
	
	@Override
	public GatewayFilter apply(Configuration config) {
		return new OrderedGatewayFilter((exchange, chain) -> {
			// PRE
			logger.info("ejecutando PRE Gateway filter factory: "+config.message);
			
			return chain.filter(exchange).then(Mono.fromRunnable(() -> {
				// POST
				logger.info("ejecutando POST Gateway filter factory: "+config.message);
				
				Optional.ofNullable(config.cookieValue).ifPresent(cookie -> {
					exchange.getResponse().addCookie(ResponseCookie.from(config.cookieName, cookie).build());
				});
			}));
		}, 2); //Orden
	}
	
	
	// Orden de los campos para el yamp
	@Override
	public List<String> shortcutFieldOrder() {
		return Arrays.asList("message", "cookieName", "cookieValue");
	}
	
	// Nombre del filtro
	@Override
	public String name() {
		return "EjemploCookie";
	}




	// Configuracion
	public static class Configuration {
		
		private String message;
		private String cookieName;
		private String cookieValue;
		
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public String getCookieValue() {
			return cookieValue;
		}
		public void setCookieValue(String cookieValue) {
			this.cookieValue = cookieValue;
		}
		public String getCookieName() {
			return cookieName;
		}
		public void setCookieName(String cookieName) {
			this.cookieName = cookieName;
		}
	}

}
