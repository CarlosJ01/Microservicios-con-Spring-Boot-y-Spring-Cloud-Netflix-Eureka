package com.alfacentauri.cloud.gateway.filters;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

@Component
public class EjemploGlobalFilter implements GlobalFilter, Ordered{ // Para que sea un filtro

	private final Logger logger = LoggerFactory.getLogger(EjemploGlobalFilter.class);
	
	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
		// Antes de la peticion PRE
		logger.info("Ejecutando filtro PRE");
		
		// Modificar el request
		exchange.getRequest().mutate().headers(h -> h.add("token", "1234567890"));
		
		// Continuar con los demas filtros -> Then despues de la respuesta
		return chain.filter(exchange).then(Mono.fromRunnable(()->{
			// Despues de la peticion POST
			logger.info("Ejecutando filtro POST");
			
			// Modificamos la espuesta
			exchange.getResponse().getCookies().add("color", ResponseCookie.from("color", "rojo").build());
//			exchange.getResponse().getHeaders().setContentType(MediaType.TEXT_PLAIN);
			
			// Verificar si es null lo que regresa
			Optional.ofNullable(exchange.getRequest().getHeaders().getFirst("token")).ifPresent(token -> {
				exchange.getResponse().getHeaders().add("token", token);
			});
		})); 
	}
	
	// Orden en el que se ejecutan
	@Override
	public int getOrder() {
		return 1;
	}

}
