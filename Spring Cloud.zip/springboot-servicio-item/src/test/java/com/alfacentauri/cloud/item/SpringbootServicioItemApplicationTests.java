package com.alfacentauri.cloud.item;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioItemApplicationTests {

	@Test
	void contextLoads() {
	}

}
