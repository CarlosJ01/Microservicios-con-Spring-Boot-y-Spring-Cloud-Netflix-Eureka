package com.alfacentauri.cloud.item;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

//@EnableCircuitBreaker // Habilitar hystrix para tolerancia a fallos con hystrics
@EnableEurekaClient // Habilitar cliente de eureka
//@RibbonClient(name = "servicio-productos") // Registra cliente de Ribbon
@EnableFeignClients // Abilitar el cliente de Feign
@SpringBootApplication
@EntityScan({"com.alfacentauri.cloud.commons.entitys"})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})
public class SpringbootServicioItemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootServicioItemApplication.class, args);
	}

}
