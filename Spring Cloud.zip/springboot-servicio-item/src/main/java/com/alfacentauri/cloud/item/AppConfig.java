package com.alfacentauri.cloud.item;

import java.time.Duration;

import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JCircuitBreakerFactory;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JConfigBuilder;
import org.springframework.cloud.client.circuitbreaker.Customizer;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.timelimiter.TimeLimiterConfig;

@Configuration
public class AppConfig {
	
	@Bean("clienteRest")
	@LoadBalanced // Balanceo de carga
	public RestTemplate registrarRestTemplate() {
		return new RestTemplate();
	}
	
	// Configuracion de resilience4j en corto circuito
//	@Bean
//	public Customizer<Resilience4JCircuitBreakerFactory> defaultCustomizer() {
//		return factory -> factory.configureDefault(id -> {
//			return new Resilience4JConfigBuilder(id).circuitBreakerConfig(
//					CircuitBreakerConfig.custom()
//						.slidingWindowSize(10) // Muestra de fallos defualt 100
//						.failureRateThreshold(50) //Porcentaje de error
//						.waitDurationInOpenState(Duration.ofSeconds(10L)) // Duracion del estado habierto
//						.permittedNumberOfCallsInHalfOpenState(5) // Numero de llamadas en semi-abierto
//						.slowCallRateThreshold(50) // Porcentaje de llamadas lentas
//						.slowCallDurationThreshold(Duration.ofSeconds(1l)) // Duracion de las llamadas lentas 
//																			// cuando se define que es una llamada lenta
//						.build()
//					).timeLimiterConfig( //Limite de tiempo en la llamada default 1s antes de lanzar un timeout
//							TimeLimiterConfig.custom() 
//								.timeoutDuration(Duration.ofSeconds(3l))
//								.build()
//					).build();
//		});
//	}
	
}
