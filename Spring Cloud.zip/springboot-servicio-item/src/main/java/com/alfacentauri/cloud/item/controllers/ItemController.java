package com.alfacentauri.cloud.item.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.alfacentauri.cloud.commons.entitys.Producto;
import com.alfacentauri.cloud.item.models.Item;
import com.alfacentauri.cloud.item.services.ItemService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;

@RefreshScope // Actualizar los componentes
@RestController
public class ItemController {

	private final Logger logger = LoggerFactory.getLogger(ItemController.class);

	// Constructor para recilencias
	@Autowired
	private CircuitBreakerFactory circuitBreakerFactory;

	@Autowired
	@Qualifier("serviceFeign")
	private ItemService itemService;
	
	@Value("${configuracion.texto}")
	private String texto;
	
	@Autowired
	private Environment environment; // Variables del entorno
	
	@GetMapping("/get-config")
	public ResponseEntity<Map<String,String>> getCongfig(@Value("${server.port}") String port) {
		logger.info(texto);
		
		Map<String,String> json = new HashMap<>();
		json.put("texto", texto);
		json.put("port", port);
		
		if(environment.getActiveProfiles().length > 0 && environment.getActiveProfiles()[0].equals("dev")) {
			json.put("autor.nombre", environment.getProperty("configuracion.autor.nombre"));
			json.put("autor.email", environment.getProperty("configuracion.autor.email"));			
		}
		
		return new ResponseEntity<Map<String,String>>(json, HttpStatus.OK);
	}
	
	@GetMapping("/listar")
	public List<Item> listar(@RequestParam(name = "nombre", required = false) String nombre,
			@RequestHeader(name = "token-request", required = false) String token) {
		System.out.println(nombre);
		System.out.println(token);
		return itemService.findAll();
	}

//	@HystrixCommand(fallbackMethod = "metodoAlternativo") // En caso de fallo llama a este metodo con hystrix
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	public Item detalle(@PathVariable Long id, @PathVariable Integer cantidad) {
		// Tolerancia a fallas con Resilience4j
		return circuitBreakerFactory.create("items").run(() -> itemService.findById(id, cantidad), // Normal
				error -> this.metodoAlternativo(id, cantidad, error) // Ruta alternativa
		);
	}

	// Creando un circuito con su nombre y camino alternativo, solo se puede pasar
	// configuracion por yml y solo maneja excepciones no time out
	@CircuitBreaker(name = "items", fallbackMethod = "metodoAlternativo")
	@GetMapping("/ver2/{id}/cantidad/{cantidad}")
	public Item detalle2(@PathVariable Long id, @PathVariable Integer cantidad) {
		return itemService.findById(id, cantidad);
	}

	// Otra forma de circuito pero con llamadas asyncronicas, solo maneja timeout no
	// execpciones pero no entra en corto circuito
	@TimeLimiter(name = "items", fallbackMethod = "metodoAlternativoAsyncronico")
	@GetMapping("/ver3/{id}/cantidad/{cantidad}")
	public CompletableFuture<Item> detalle3(@PathVariable Long id, @PathVariable Integer cantidad) {
		return CompletableFuture.supplyAsync(() -> itemService.findById(id, cantidad));
	}

	// Conviancion de hambos ahora funciona normal
	@CircuitBreaker(name = "items", fallbackMethod = "metodoAlternativoAsyncronico")
	@TimeLimiter(name = "items")
	@GetMapping("/ver4/{id}/cantidad/{cantidad}")
	public CompletableFuture<Item> detalle4(@PathVariable Long id, @PathVariable Integer cantidad) {
		return CompletableFuture.supplyAsync(() -> itemService.findById(id, cantidad));
	}

	// Camino secundario
	public Item metodoAlternativo(Long id, Integer cantidad, Throwable error) {
		logger.error(error.getMessage());
		Producto producto = new Producto();
		producto.setId(id);
		producto.setNombre("Error");
		producto.setPrecio(0.0);
		return new Item(producto, cantidad);
	}

	public CompletableFuture<Item> metodoAlternativoAsyncronico(Long id, Integer cantidad, Throwable error) {
		logger.error(error.getMessage());
		return CompletableFuture.supplyAsync(() -> {
			Producto producto = new Producto();
			producto.setId(id);
			producto.setNombre("Error");
			producto.setPrecio(0.0);
			return new Item(producto, cantidad);
		});
	}
	
	@PostMapping("/crear")
	@ResponseStatus(code = HttpStatus.CREATED)
	public Producto crear(@RequestBody Producto producto) {
		return itemService.save(producto);
	}
	
	@PutMapping("/editar/{id}")
	@ResponseStatus(code = HttpStatus.CREATED)
	public Producto editar(@RequestBody Producto producto, @PathVariable Long id) {
		return itemService.update(producto, id);
	}
	
	@DeleteMapping("/eliminar/{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long id) {
		itemService.delete(id);
	}
	
}
