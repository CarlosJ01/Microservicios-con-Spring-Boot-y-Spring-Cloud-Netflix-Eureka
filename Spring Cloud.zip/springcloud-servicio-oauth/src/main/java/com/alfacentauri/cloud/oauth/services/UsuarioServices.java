package com.alfacentauri.cloud.oauth.services;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.alfacentauri.cloud.commons.usuarios.entitys.Usuario;
import com.alfacentauri.cloud.oauth.clients.UsuarioFeignClient;

import brave.Tracer;

// Una especie de login
@Service
public class UsuarioServices implements UserDetailsService, IUsuarioService {
	
	private final Logger logger = LoggerFactory.getLogger(UsuarioServices.class);
	
	@Autowired
	private UsuarioFeignClient client;
	
	@Autowired
	private Tracer tracer;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// Get usuario
		Usuario usuario;
		try {
			usuario = client.findByUsername(username);
		} catch (Exception e) {
			String error = "Error en el login, usuario "+username+"no encontrado";
			logger.error(error);			
			tracer.currentSpan().tag("error.message", error); // Mensaje de la traza de zipkin
			throw new UsernameNotFoundException(error);
		}
		
		// Optener los roles
		List<GrantedAuthority> authorities = usuario.getRoles().stream()
				.map(rol -> new SimpleGrantedAuthority(rol.getNombre()))
				.peek(authority -> logger.info("Role: "+authority.getAuthority()))
				.collect(Collectors.toList());
		
		logger.info("Usuario autenticado: " + username);
		
		// Retornar el usuario
		return new User(usuario.getUsername(), usuario.getPassword(), usuario.getEnabled(), 
				true, true, true, 
				authorities);
	}

	@Override
	public Usuario findByUsername(String username) {
		return client.findByUsername(username);
	}

	@Override
	public Usuario update(Usuario usuario, Long id) {
		return client.update(usuario, id);
	}

}
