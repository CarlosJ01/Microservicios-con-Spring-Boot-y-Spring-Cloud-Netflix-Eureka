package com.alfacentauri.cloud.oauth.security.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Component;

import com.alfacentauri.cloud.commons.usuarios.entitys.Usuario;
import com.alfacentauri.cloud.oauth.services.IUsuarioService;

import brave.Tracer;
import feign.FeignException;

// Manejo de Eventos de Authenticacion
@Component
public class AuthenticationSuccessErrorHandler implements AuthenticationEventPublisher {

	private Logger log = LoggerFactory.getLogger(AuthenticationSuccessErrorHandler.class);

	@Autowired
	private IUsuarioService service;
	
	@Autowired
	private Tracer tracer;
	
	@Override
	public void publishAuthenticationSuccess(Authentication authentication) {
		if (authentication.getDetails() instanceof WebAuthenticationDetails) {
			return;
		}
		UserDetails user = (UserDetails) authentication.getPrincipal();
		log.info("Success login " + user.getUsername());
		
		// Manejo de itentos de inicio de loging
		try {
			Usuario usuario = service.findByUsername(authentication.getName());
			if (usuario.getIntentos() != null && usuario.getIntentos() > 0) {
				usuario.setIntentos(0);
				service.update(usuario, usuario.getId());
			}
			
		} catch (FeignException e) {
			log.error(String.format("El usuario %s no existe en el sistema", authentication.getName()));
		}
	}

	@Override
	public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {
		log.error("Error login " + exception.getMessage());
		
		// Manejo de itentos de inicio de loging
		try {
			
			StringBuilder errors = new StringBuilder();
			errors.append("Error login " + exception.getMessage());
			errors.append("|");
			
			Usuario usuario = service.findByUsername(authentication.getName());
			if (usuario.getIntentos() == null)
				usuario.setIntentos(0);
			
			usuario.setIntentos(usuario.getIntentos()+1);
			log.error(String.format("El usuario %s intento # %s", authentication.getName(), usuario.getIntentos().toString()));
			
			errors.append(String.format("El usuario %s intento # %s", authentication.getName(), usuario.getIntentos().toString()));
			errors.append("|");
			
			if (usuario.getIntentos() >= 3) {
				log.error(String.format("El usuario %s desabilitado por 3 itentos", authentication.getName()));
				
				errors.append(String.format("El usuario %s desabilitado por 3 itentos", authentication.getName()));
				errors.append("|");
				
				usuario.setEnabled(false);
			}
			
			service.update(usuario, usuario.getId());
			
			tracer.currentSpan().tag("error.message", errors.toString()); // Mensaje de la traza de zipkin
			
		} catch (FeignException e) {
			log.error(String.format("El usuario %s no existe en el sistema", authentication.getName()));
		}
		
		
	}

}
