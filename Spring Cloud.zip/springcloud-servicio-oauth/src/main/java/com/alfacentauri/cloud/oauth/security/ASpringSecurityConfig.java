package com.alfacentauri.cloud.oauth.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class ASpringSecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private AuthenticationEventPublisher eventPublisher;
	
	@Autowired
	private UserDetailsService service;
	
	// Crear el codificador de contraseñas
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Override
	protected void configure(@Autowired AuthenticationManagerBuilder auth) throws Exception {
		// Configura el servico que busca al usuario y el codificador
		auth.userDetailsService(this.service).passwordEncoder(passwordEncoder());
		auth.authenticationEventPublisher(eventPublisher); // Registro de eventos
	}
	
	@Override
	@Bean("authenticationManagerCustom")
	protected AuthenticationManager authenticationManager() throws Exception {
		// Configura el Authentication Manager
		return super.authenticationManager();
	}
	
}
