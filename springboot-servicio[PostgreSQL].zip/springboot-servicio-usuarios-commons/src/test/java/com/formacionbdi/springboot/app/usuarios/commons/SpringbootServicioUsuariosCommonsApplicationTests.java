package com.formacionbdi.springboot.app.usuarios.commons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioUsuariosCommonsApplicationTests {

	@Test
	void contextLoads() {
	}

}
